import matplotlib.pyplot as plt

print("Hello World")