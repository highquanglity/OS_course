

// First Go program
package main
 
import "fmt";
 
// Main function
func main() {
 
    fmt.Println("!... Hello World ...!")
}
