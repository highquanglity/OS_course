#include <stdio.h>
int main() {
    printf("Hi, I am a C program\n");
    return 0;
}